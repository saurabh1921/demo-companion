#!/bin/bash
# Builds adyatube.apk with plain SDK tools (no Gradle).
set -euo pipefail
cd "$(dirname "$0")"
SDK="$HOME/Library/Android/sdk"
BT="$SDK/build-tools/34.0.0"
PLAT="$SDK/platforms/android-34/android.jar"
export PATH="/opt/homebrew/opt/openjdk@17/bin:$PATH"
rm -rf build && mkdir -p build/classes build/res
"$BT/aapt2" compile --dir res -o build/res/res.zip
"$BT/aapt2" link -o build/base.apk -I "$PLAT" --manifest AndroidManifest.xml \
  --min-sdk-version 22 --target-sdk-version 28 --version-code "$(( $(date +%s) / 60 ))" --version-name "2.$(date +%m%d.%H%M)" -A assets build/res/res.zip
javac -nowarn -source 8 -target 8 -classpath "$PLAT" -d build/classes $(find src -name '*.java') 2>&1 | grep -vE "bootstrap classpath|^warning|^1 warning|JAVA_TOOL" || true
"$BT/d8" --min-api 22 --lib "$PLAT" --output build $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build && zip -q unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
KS=../tvmsg/debug.keystore
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:android --out adyatube.apk build/aligned.apk
echo "Built $(pwd)/adyatube.apk"
