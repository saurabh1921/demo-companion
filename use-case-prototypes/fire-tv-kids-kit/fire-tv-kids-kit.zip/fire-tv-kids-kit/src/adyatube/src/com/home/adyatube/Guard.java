package com.home.adyatube;

import android.content.Context;
import android.content.SharedPreferences;

/** Quiz guard state shared by KeyService (timer) and the quiz screens. */
final class Guard {
    private Guard() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("guard", Context.MODE_PRIVATE);
    }

    /** A quiz is waiting to be passed: every app is blocked until then. */
    static boolean owed(Context c) { return prefs(c).getBoolean("owed", false); }

    static void setOwed(Context c, boolean v) { prefs(c).edit().putBoolean("owed", v).apply(); }

    static long lastPass(Context c) { return prefs(c).getLong("lastPass", 0); }

    /** Seconds watched since the last quiz. */
    static int watched(Context c) { return lazy >= 0 ? lazy : prefs(c).getInt("watched", 0); }

    static void setWatched(Context c, int sec) { lazy = sec; prefs(c).edit().putInt("watched", sec).apply(); }

    /** Cheap in-memory copy between disk saves (KeyService saves every 30 s). */
    private static int lazy = -1;
    static void setWatchedLazy(Context c, int sec) { lazy = sec; }

    static void passed(Context c) {
        prefs(c).edit().putBoolean("owed", false).putLong("lastPass", System.currentTimeMillis()).putInt("watched", 0).apply();
        lazy = 0;
    }
}
