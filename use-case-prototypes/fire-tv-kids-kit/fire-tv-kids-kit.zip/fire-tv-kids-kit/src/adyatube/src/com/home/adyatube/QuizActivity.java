package com.home.adyatube;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

/**
 * Kids Quiz: the quiz on its own screen, shown over any app (Netflix, Prime, YouTube...).
 * Opened by the quiz guard in KeyService every N minutes of watching and when the TV turns on.
 * Same app as Kids Videos, so quiz history, trophies and the top bar are shared.
 * Passing the quiz closes this screen and the app underneath (paused) comes back.
 *
 * am start -n com.home.adyatube/.QuizActivity     (quiz now)
 */
public class QuizActivity extends MainActivity {
    private AudioManager audio;
    private final AudioManager.OnAudioFocusChangeListener focus = new AudioManager.OnAudioFocusChangeListener() {
        @Override public void onAudioFocusChange(int change) { }
    };

    private boolean skipping;
    /** True while the quiz screen is in front (window events only give "FrameLayout", not the activity). */
    static volatile boolean shown;

    /** Parent skip from the dashboard: am start -n com.home.adyatube/.QuizActivity --ez skip true */
    private boolean skip(Intent i) {
        if (i == null || !i.getBooleanExtra("skip", false)) return false;
        skipping = true;
        Guard.passed(this);
        if (audio != null) audio.abandonAudioFocus(focus);
        finish();
        return true;
    }

    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        skip(getIntent());
    }

    @Override
    protected String startUrl() { return BASE + "index.html?qonly=1"; }

    @Override
    protected void onNewIntent(Intent intent) {
        if (skip(intent)) return;
        js("window.guardQuiz && loadQuizCfg().then(function(){ guardQuiz(true); })");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (skipping) return;
        shown = true;
        Guard.setOwed(this, true);
        // taking audio focus makes Netflix / Prime / music pause, even if they ignore losing the screen
        if (audio == null) audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audio.requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
    }

    @Override
    protected void onPause() {
        super.onPause();
        shown = false;
        if (isFinishing() && audio != null) audio.abandonAudioFocus(focus);
    }

    @Override
    protected void onGuardDone() {
        if (audio != null) audio.abandonAudioFocus(focus);
        finish();                       // back to whatever was underneath
    }
}
