package com.home.adyatube;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.os.Build;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Kid-safe YouTube: plays only videos from an approved list.
 * The list lives at <external files>/videos.json and is pushed by the parent dashboard.
 *
 * am start -n com.home.adyatube/.MainActivity --es play VIDEO_ID   (play one approved video)
 */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String BASE = "https://" + HOST + "/";
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    /** Read quiz questions aloud (created on first use to keep startup light). */
    private void speak(final String text) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (tts == null) {
                    // Amazon's Ivona engine has no voice installed on this TV; Pico ships in /system with English.
                    tts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                        @Override public void onInit(int status) {
                            if (status != TextToSpeech.SUCCESS || tts == null) return;
                            Locale loc = Locale.UK;
                            if (tts.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) loc = Locale.US;
                            tts.setLanguage(loc);
                            tts.setSpeechRate(0.9f);
                            ttsReady = true;
                            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "q");
                        }
                    }, "com.svox.pico");
                } else if (ttsReady) {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "q");
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getExternalFilesDir(null); // make sure the folder exists for the dashboard to push into

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#FFF4E6"));
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        if (Build.VERSION.SDK_INT >= 23) s.setOffscreenPreRaster(true);
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(false);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            /** Page reports what is playing; the dashboard reads now.json over adb. */
            @JavascriptInterface
            public void now(String json) {
                if (json == null || json.length() > 40000) return;
                File f = new File(getExternalFilesDir(null), "now.json");
                try (FileOutputStream out = new FileOutputStream(f)) {
                    out.write(json.getBytes("UTF-8"));
                } catch (IOException ignored) { }
            }

            @JavascriptInterface
            public void speak(String text) {
                if (text != null && text.length() <= 400) MainActivity.this.speak(text);
            }

            /** A quiz was passed. guard = it was the Kids Quiz screen, so go back to Netflix etc. */
            @JavascriptInterface
            public void quizPassed(final boolean guard) {
                Guard.passed(MainActivity.this);
                if (guard) runOnUiThread(new Runnable() { @Override public void run() { onGuardDone(); } });
            }

            @JavascriptInterface
            public void stopSpeaking() {
                runOnUiThread(new Runnable() { @Override public void run() { if (tts != null) tts.stop(); } });
            }
        }, "AdyaBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                if ("www.youtube-nocookie.com".equals(req.getUrl().getHost())
                        && req.getUrl().getPath() != null && req.getUrl().getPath().startsWith("/embed/")
                        && "GET".equals(req.getMethod())) {
                    return tunedEmbed(req);
                }
                if (!HOST.equals(req.getUrl().getHost())) return null;
                String path = req.getUrl().getPath();
                try {
                    if ("/videos.json".equals(path)) {
                        File f = new File(getExternalFilesDir(null), "videos.json");
                        InputStream in = f.exists() ? new FileInputStream(f) : getAssets().open("videos.json");
                        WebResourceResponse r = new WebResourceResponse("application/json", "utf-8", in);
                        return r;
                    }
                    if ("/".equals(path) || "/index.html".equals(path)) {
                        return new WebResourceResponse("text/html", "utf-8", getAssets().open("index.html"));
                    }
                    if (path != null && path.matches("/[A-Za-z0-9_-]+\\.(ttf|png|svg)")) {
                        String type = path.endsWith(".ttf") ? "font/ttf"
                                : path.endsWith(".png") ? "image/png" : "image/svg+xml";
                        return new WebResourceResponse(type, null, getAssets().open(path.substring(1)));
                    }
                } catch (IOException ignored) { }
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // Never leave the app: block navigation to youtube.com etc.
                return !HOST.equals(req.getUrl().getHost());
            }
        });
        setContentView(web);
        web.loadUrl(startUrl());
        web.requestFocus(View.FOCUS_DOWN);
    }

    /** Max video height the player may pick (from videos.json "quality"; default 720). */
    private int maxHeight() {
        try {
            File f = new File(getExternalFilesDir(null), "videos.json");
            if (!f.exists()) return 720;
            byte[] b = new byte[(int) Math.min(f.length(), 2_000_000)];
            try (FileInputStream in = new FileInputStream(f)) { int n = in.read(b); if (n <= 0) return 720; }
            int q = new JSONObject(new String(b, "UTF-8")).optInt("quality", 720);
            return (q >= 240 && q <= 2160) ? q : 720;
        } catch (Exception e) { return 720; }
    }

    /**
     * Fetch the YouTube embed page ourselves and inject a tiny script before YouTube's player code runs.
     * It hides heavy formats from YouTube's quality picker: only H.264 (hardware-decoded on Fire TV),
     * no 60 fps, nothing above the chosen height. YouTube still adapts to the internet speed below that cap.
     * On any failure we return null and the WebView loads the page normally.
     */
    private WebResourceResponse tunedEmbed(WebResourceRequest req) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(req.getUrl().toString()).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            for (Map.Entry<String, String> h : req.getRequestHeaders().entrySet()) {
                String k = h.getKey();
                if (k == null || k.equalsIgnoreCase("Accept-Encoding")) continue;   // let Java handle gzip
                c.setRequestProperty(k, h.getValue());
            }
            if (c.getRequestProperty("Referer") == null) c.setRequestProperty("Referer", BASE + "index.html");
            if (c.getResponseCode() != 200) return null;
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[16384]; int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            }
            String html = buf.toString("UTF-8");
            int maxH = maxHeight();
            String patch = "<script>(function(){var MAXH=" + maxH + ";"
                + "function bad(t){t=String(t||'').toLowerCase();"
                + "if(t.indexOf('video')===0&&!/avc1|avc3/.test(t))return true;"          // video must be H.264
                + "var h=/height=(\\d+)/.exec(t);if(h&&+h[1]>MAXH)return true;"
                + "var w=/width=(\\d+)/.exec(t);if(w&&+w[1]>Math.ceil(MAXH*16/9)+8)return true;"
                + "var f=/framerate=(\\d+)/.exec(t);if(f&&+f[1]>31)return true;return false;}"
                + "['MediaSource','ManagedMediaSource','WebKitMediaSource'].forEach(function(n){var M=window[n];"
                + "if(M&&M.isTypeSupported){var o=M.isTypeSupported.bind(M);M.isTypeSupported=function(t){return bad(t)?false:o(t);};}});"
                + "var cp=HTMLMediaElement.prototype.canPlayType;"
                + "HTMLMediaElement.prototype.canPlayType=function(t){return bad(t)?'':cp.call(this,t);};"
                + "})();</script>";
            int at = html.indexOf("<head>");
            html = at >= 0 ? html.substring(0, at + 6) + patch + html.substring(at + 6) : patch + html;
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("text/html", "utf-8", 200, "OK", headers,
                    new java.io.ByteArrayInputStream(html.getBytes("UTF-8")));
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Page to open; QuizActivity (Kids Quiz) overrides this. */
    protected String startUrl() {
        return BASE + "index.html" + ("quiz".equals(getIntent().getStringExtra("action")) ? "?quiz=1" : playQuery(getIntent()));
    }

    /** Called after a guard quiz is passed (only on the Kids Quiz screen). */
    protected void onGuardDone() { }

    protected void js(String code) { if (web != null) web.evaluateJavascript(code, null); }

    private static String playQuery(Intent i) {
        String id = i == null ? null : i.getStringExtra("play");
        return (id != null && id.matches("[A-Za-z0-9_-]{11}")) ? "?play=" + id : "";
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if ("quiz".equals(intent.getStringExtra("action"))) {
            web.evaluateJavascript("window.reloadList && reloadList(true).then(function(){ startQuiz(true); })", null);
            return;
        }
        String q = playQuery(intent);
        if (!q.isEmpty()) web.evaluateJavascript(
                "window.reloadList && reloadList().then(function(){ playById('" + q.substring(6) + "'); })", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        // Kids Quiz may have changed quiz history/trophies while we were in the background
        web.evaluateJavascript("window.reloadQZ && reloadQZ(); window.reloadList && reloadList()", null);
    }

    @Override
    protected void onPause() {
        web.evaluateJavascript("window.pauseVideo && pauseVideo()", null);
        web.onPause();
        super.onPause();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean ours = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                || code == KeyEvent.KEYCODE_MEDIA_PLAY || code == KeyEvent.KEYCODE_MEDIA_PAUSE
                || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code == KeyEvent.KEYCODE_MEDIA_REWIND;
        if (e.getAction() != KeyEvent.ACTION_DOWN) return ours || super.dispatchKeyEvent(e);
        if (e.getRepeatCount() > 0 && ours) return true;
        switch (code) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                web.evaluateJavascript("window.togglePlay && togglePlay()", null);
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                web.evaluateJavascript("window.seekBy && seekBy(10)", null);
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                web.evaluateJavascript("window.seekBy && seekBy(-10)", null);
                return true;
            case KeyEvent.KEYCODE_BACK:
                web.evaluateJavascript("window.onBack ? onBack() : false", new ValueCallback<String>() {
                    @Override public void onReceiveValue(String handled) {
                        if (!"true".equals(handled)) finish();
                    }
                });
                return true;
            default:
                return super.dispatchKeyEvent(e);
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
