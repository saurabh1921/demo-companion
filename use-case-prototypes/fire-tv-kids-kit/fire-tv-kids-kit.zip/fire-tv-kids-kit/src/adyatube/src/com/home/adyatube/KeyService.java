package com.home.adyatube;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import org.json.JSONObject;
import java.io.FileInputStream;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Remaps a remote button (e.g. the Amazon Music app button) to open Kids Videos.
 *
 * The trigger key codes live in <external files>/button.txt (one integer per line), so the
 * dashboard can change them without a rebuild. Every key seen is logged under the tag
 * "AdyaKeys" and the last ones are written to keys.txt, which is how we learn a button's code.
 * All other keys pass through untouched.
 */
public class KeyService extends AccessibilityService {
    private static final String TAG = "AdyaKeys";
    private Set<Integer> triggers = new HashSet<>();
    private long loadedAt = 0;
    private final StringBuilder recent = new StringBuilder();

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        loadTriggers();
        Log.i(TAG, "service connected, triggers=" + triggers);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screen, f);
        tick.run();
        if (SystemClock.elapsedRealtime() < 10 * 60000) onWake("boot");     // Fire TV just started
    }

    // ---------------- quiz guard (Kids Quiz) ----------------
    // Every quiz.every_min minutes of watching any app → Kids Quiz pops up over it.
    // When the TV turns on (and no quiz passed in quiz.entry_gap_min) → Kids Quiz first.
    // While a quiz is owed, leaving it (Home, another app) brings it straight back.
    private static final String QUIZ_CLASS = "com.home.adyatube.QuizActivity";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String fgPkg = "", fgCls = "";
    private long lastLaunch = 0, cfgStamp = -1;
    private boolean qEnabled = true;
    private int everyMin = 10, wakeGapMin = 30, unsaved = 0;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            handler.postDelayed(this, 5000);
            try { guardTick(5); } catch (Exception e) { Log.w(TAG, "guard", e); }
        }
    };

    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) onWake("screen on");
        }
    };

    private void loadQuizCfg() {
        File f = new File(getExternalFilesDir(null), "videos.json");
        long stamp = f.exists() ? f.lastModified() : 0;
        if (stamp == cfgStamp) return;
        cfgStamp = stamp;
        if (!f.exists()) return;
        try {
            byte[] b = new byte[(int) Math.min(f.length(), 4_000_000)];
            int n;
            try (FileInputStream in = new FileInputStream(f)) { n = in.read(b); }
            JSONObject q = new JSONObject(new String(b, 0, Math.max(n, 0), "UTF-8")).optJSONObject("quiz");
            if (q == null) return;
            qEnabled = q.optBoolean("enabled", true);
            everyMin = Math.max(1, q.optInt("every_min", 10));
            wakeGapMin = Math.max(0, q.optInt("entry_gap_min", 30));
        } catch (Exception e) { Log.w(TAG, "quiz cfg", e); }
    }

    private boolean screenOn() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm == null || pm.isInteractive();
    }

    private boolean isLauncher(String p) { return p.equals("com.amazon.tv.launcher"); }

    /** Apps where the quiz never interrupts: settings (parent escape) and the screensaver. */
    private boolean exempt(String p) {
        return p.startsWith("com.amazon.tv.settings") || p.contains("screensaver") || p.startsWith("com.amazon.bueller") || p.isEmpty();
    }

    /** Pop-ups that sit over the real app (keyboard, Alexa, volume...): don't count as switching app. */
    private static boolean overlay(String p) {
        return p.equals("android") || p.equals("com.android.systemui") || p.contains("inputmethod") || p.contains("keyboard")
                || p.contains("vizzini") || p.contains("alexa") || p.contains("notification");
    }

    /** Ask the system which app is on screen (window events alone miss the app open when we (re)start). */
    private void refreshForeground() {
        try {
            android.view.accessibility.AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r == null) return;
            CharSequence p = r.getPackageName();
            r.recycle();
            if (p != null && !overlay(p.toString()) && !p.toString().equals(fgPkg)) { fgPkg = p.toString(); fgCls = ""; }
        } catch (Exception ignored) { }
    }

    private void guardTick(int sec) {
        loadQuizCfg();
        refreshForeground();
        if (!qEnabled || !screenOn()) return;
        boolean ownQuiz = QuizActivity.shown && getPackageName().equals(fgPkg);
        if (Guard.owed(this)) {
            if (!ownQuiz && !exempt(fgPkg)) launchQuiz("owed, she is in " + fgPkg);
            return;
        }
        boolean own = getPackageName().equals(fgPkg);
        boolean watching = own ? ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).isMusicActive()   // YouTube: only while playing
                : !isLauncher(fgPkg) && !exempt(fgPkg);                                                    // Netflix etc.: while open
        if (!watching) return;
        int w = Guard.watched(this) + sec;
        if (w >= everyMin * 60) {
            Guard.setOwed(this, true);
            Guard.setWatched(this, 0);
            launchQuiz(everyMin + " min of " + fgPkg);
            return;
        }
        if (++unsaved >= 6) { unsaved = 0; Guard.setWatched(this, w); } else Guard.setWatchedLazy(this, w);
    }

    private void onWake(String why) {
        loadQuizCfg();
        if (!qEnabled || wakeGapMin <= 0) return;
        if (System.currentTimeMillis() - Guard.lastPass(this) < wakeGapMin * 60000L) return;
        Guard.setOwed(this, true);
        handler.postDelayed(new Runnable() { @Override public void run() { launchQuiz(why); } }, 4000);   // let the home screen load
    }

    private void launchQuiz(String why) {
        long now = System.currentTimeMillis();
        if (now - lastLaunch < 2500) return;
        lastLaunch = now;
        note("Kids Quiz: " + why);
        Intent i = new Intent();
        i.setClassName(this, QUIZ_CLASS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { Log.w(TAG, "launch quiz", e); }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(screen); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void loadTriggers() {
        Set<Integer> t = new HashSet<>();
        File f = new File(getExternalFilesDir(null), "button.txt");
        if (f.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.matches("\\d{1,4}")) t.add(Integer.parseInt(line));
                }
            } catch (IOException ignored) { }
        }
        triggers = t;
        loadedAt = System.currentTimeMillis();
    }

    private void remember(KeyEvent e) {
        note("code=" + e.getKeyCode() + " scan=" + e.getScanCode()
                + " action=" + e.getAction() + " name=" + KeyEvent.keyCodeToString(e.getKeyCode()));
    }

    private void note(String what) {
        String line = System.currentTimeMillis() / 1000 + " " + what + "\n";
        Log.i(TAG, line.trim());
        recent.append(line);
        if (recent.length() > 4000) recent.delete(0, recent.length() - 3000);
        try (FileOutputStream out = new FileOutputStream(new File(getExternalFilesDir(null), "keys.txt"))) {
            out.write(recent.toString().getBytes("UTF-8"));
        } catch (IOException ignored) { }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        remember(e);
        if (System.currentTimeMillis() - loadedAt > 30000) loadTriggers();   // pick up dashboard changes
        if (!triggers.contains(e.getKeyCode())) return false;                  // not ours: pass through
        if (e.getAction() == KeyEvent.ACTION_UP) {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        }
        return true;                                                            // swallow down + up
    }

    private long appLaunchAt = 0, redirectedAt = 0;

    /**
     * The Amazon Music remote button doesn't send a key: it asks the Appstore to launch Amazon Music
     * (disabled on this TV), so the Appstore shows AppLaunchActivity then the app's details page.
     * That exact pair = "a remote app button for an unavailable app" → open Kids Videos instead.
     */
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        String cls = event.getClassName() == null ? "" : event.getClassName().toString();
        note("window " + pkg + "/" + cls);
        if (!overlay(pkg)) {
            boolean changed = !pkg.equals(fgPkg);
            fgPkg = pkg; fgCls = cls;
            if (changed && Guard.owed(this)) {   // escaped the quiz: bring it back fast
                handler.postDelayed(new Runnable() { @Override public void run() { try { guardTick(0); } catch (Exception ignored) { } } }, 700);
            }
        }
        if (!"com.amazon.venezia".equals(pkg)) return;
        long now = System.currentTimeMillis();
        if (cls.endsWith(".pdi.AppLaunchActivity")) {
            appLaunchAt = now;
        } else if (cls.endsWith(".details.AppDetailsActivity") && now - appLaunchAt < 3000 && now - redirectedAt > 3000) {
            redirectedAt = now;
            note("app button for unavailable app -> opening Kids Videos");
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }
    }

    @Override
    public void onInterrupt() { }
}
