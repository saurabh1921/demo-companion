#!/bin/bash
# Uninstall + reinstall Kids Videos so the Fire TV home screen picks up the new tile.
# Refuses if the TV is in use. Usage: ./fresh_reinstall.sh [--force]
cd "$(dirname "$0")"
DEV=$(python3 -c "import json;print(json.load(open('config.json'))['device'])")
if [ "${1:-}" != "--force" ]; then
  ./safe_install.sh --dry-run adyatube/adyatube.apk || exit 2
fi
adb -s $DEV uninstall com.home.adyatube
adb -s $DEV install adyatube/adyatube.apk || exit 1
adb -s $DEV shell am start -n com.home.adyatube/.MainActivity >/dev/null   # creates its files folder
sleep 2
python3 -I -c "import sys; sys.path.insert(0,'.'); import server as s; print('list pushed:', s.sync_kids_list())" 2>/dev/null | grep pushed
adb -s $DEV shell input keyevent 3   # back to Home to show the tile
sleep 3
adb -s $DEV exec-out screencap -p > /tmp/home_tile.png && echo "screenshot: /tmp/home_tile.png"
