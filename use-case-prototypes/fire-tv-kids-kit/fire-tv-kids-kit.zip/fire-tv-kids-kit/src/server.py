#!/usr/bin/env python3
"""Fire TV parental remote — local dashboard server.

Stdlib only. Talks to the Fire TV over ADB (Wi-Fi).
Run:  python3 server.py      then open the URL it prints.
"""
import hmac
import json
import os
import re
import secrets
import shlex
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")
HISTORY_PATH = os.path.join(HERE, "history.jsonl")
INDEX_PATH = os.path.join(HERE, "index.html")
PORT = int(os.environ.get("FIRETV_PORT", "8765"))

APPS = {
    "youtube": {"name": "YouTube", "pkg": "com.amazon.firetv.youtube"},
    "netflix": {"name": "Netflix", "pkg": "com.netflix.ninja"},
    "hotstar": {"name": "Hotstar", "pkg": "in.startv.hotstar"},
}
PKG_NAMES = {a["pkg"]: a["name"] for a in APPS.values()}
MEDIA_PKGS = set(PKG_NAMES) | {"com.home.adyatube"}

# Built-in Amazon apps that are safe to switch off (system UI / launcher never listed).
EXTRA_LOCKABLE = {
    "com.amazon.cloud9": "Silk Browser",
    "com.amazon.venezia": "Appstore (stops new installs)",
    "com.amazon.bueller.photos": "Amazon Photos",
    "com.amazon.bueller.music": "Amazon Music",
}
NEVER_LOCK = {"com.home.tvmsg"}
FRIENDLY = {**PKG_NAMES, **EXTRA_LOCKABLE, "com.home.adyatube": "Kids Videos"}

KEYS = {
    "up": 19, "down": 20, "left": 21, "right": 22, "ok": 23,
    "back": 4, "home": 3, "menu": 82,
    "playpause": 85, "stop": 86, "next": 87, "prev": 88, "rewind": 89, "ffwd": 90,
    "volup": 24, "voldown": 25, "mute": 164,
    "sleep": 223, "wake": 224,
}

DEFAULT_CONFIG = {
    "device": "FIRE_TV_IP:5555",
    "token": None,
    "favorites": [
        {"title": "Sail the Seven Seas | 7 times table | Numberblocks",
         "url": "https://www.youtube.com/watch?v=mkyI5Aww1GQ"},
        {"title": "Quick Math - The 7 Times Tables | Numberblocks",
         "url": "https://www.youtube.com/watch?v=wkwQ7fw_W_E"},
        {"title": "Colourful Math | Full Episodes | Numberblocks",
         "url": "https://www.youtube.com/watch?v=mRjKu4QwrE4"},
    ],
    "bedtime": {"enabled": False, "start": "21:00", "end": "07:00", "lock": False},
    "quiz": {"enabled": True, "every_min": 10, "count": 10, "pass_pct": 80,
             "min_level": 1, "max_level": 6, "speak": True, "custom": [],
             "topics": {},    # topic id -> weight (0 = off); missing = 1 (equal)
             "entry_gap_min": 30, "milestones": [30, 60], "daily_limit_min": 75,
             "unlock1_q": 15, "unlock1_min": 30, "unlock_q": 20, "unlock_min": 15, "unlock_pass": 85},
}

lock = threading.RLock()
state = {
    "timer_end": None,        # epoch seconds when screen time ends
    "timer_lock": True,       # lock apps when timer ends
    "last_title": None,
    "last_status": {},
    "events": [],             # recent enforcement messages
}


# ---------------------------------------------------------------- config ---
def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    if not cfg.get("token"):
        cfg["token"] = secrets.token_urlsafe(9)
        save_config(cfg)
    return cfg


def save_config(cfg):
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_PATH)


CONFIG = load_config()


def note(msg):
    with lock:
        state["events"].insert(0, {"ts": time.time(), "msg": msg})
        del state["events"][20:]
    print(f"[{datetime.now():%H:%M:%S}] {msg}", flush=True)


# ------------------------------------------------------------------- adb ---
def adb(*args, timeout=10, binary=False):
    cmd = ["adb", "-s", CONFIG["device"], *args]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return (b"" if binary else ""), False
    out = r.stdout if binary else r.stdout.decode(errors="replace")
    return out, r.returncode == 0


def shell(*args, timeout=10):
    """Run a device shell command; every argument is quoted for the device shell."""
    return adb("shell", " ".join(shlex.quote(str(a)) for a in args), timeout=timeout)


def is_connected():
    try:
        out = subprocess.run(["adb", "devices"], capture_output=True, timeout=5).stdout.decode()
    except subprocess.TimeoutExpired:
        return False
    return any(l.split("\t")[0] == CONFIG["device"] and l.endswith("\tdevice")
               for l in out.splitlines())


def ensure_connected():
    if is_connected():
        return True
    subprocess.run(["adb", "connect", CONFIG["device"]], capture_output=True, timeout=15)
    if is_connected():
        note("Reconnected to Fire TV")
        return True
    return False


# --------------------------------------------------------------- reading ---
STATE_NAMES = {0: "none", 1: "stopped", 2: "paused", 3: "playing", 6: "buffering", 8: "connecting"}


WATCH_PATH = os.path.join(HERE, "watch_time.json")


def load_watch():
    try:
        with open(WATCH_PATH) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def kids_watch_sync():
    """Merge Kids Videos daily watch seconds (reported by the TV app) into watch_time.json."""
    out, ok = adb("shell", "cat /sdcard/Android/data/com.home.adyatube/files/now.json")
    try:
        rep = (json.loads(out) or {}) if ok else {}
    except json.JSONDecodeError:
        return
    try:
        merge_quiz_stats(rep.get("quiz"))
    except Exception as e:
        note(f"Quiz stats error: {e}")
    days = rep.get("watch") or {}
    if not isinstance(days, dict) or not days:
        return
    w = load_watch()
    changed = False
    for k, v in days.items():
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(k)) and isinstance(v, (int, float)) and v > w.get(k, 0):
            w[k] = int(v)
            changed = True
    if changed:
        with open(WATCH_PATH, "w") as f:
            json.dump(dict(sorted(w.items())[-60:]), f)


def watch_summary():
    w = load_watch()
    today = datetime.now().strftime("%Y-%m-%d")
    days = []
    for i in range(6, -1, -1):
        d = datetime.fromtimestamp(time.time() - i * 86400)
        k = d.strftime("%Y-%m-%d")
        days.append({"date": k, "label": "Today" if i == 0 else d.strftime("%a"), "min": w.get(k, 0) // 60})
    return {"today_min": w.get(today, 0) // 60, "days": days}


def kids_now():
    out, ok = adb("shell", "cat /sdcard/Android/data/com.home.adyatube/files/now.json")
    try:
        d = json.loads(out) if ok else None
    except json.JSONDecodeError:
        return None
    if not d or not d.get("title") or d.get("state") in ("idle", "ended"):
        return None
    return {"app": "Kids Videos", "pkg": "com.home.adyatube", "title": d["title"],
            "channel": None, "state": d.get("state", "playing"), "position_s": 0}


def now_playing(fg=None):
    if fg == "com.home.adyatube":
        return kids_now()
    out, ok = adb("shell", "dumpsys media_session")
    if not ok:
        return None
    sessions, cur = [], None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("package="):
            cur = {"pkg": line[8:], "state": None, "position": None, "title": None, "channel": None}
            sessions.append(cur)
        elif cur and line.startswith("state=PlaybackState"):
            m = re.search(r"state=(\d+), position=(-?\d+)", line)
            if m:
                cur["state"], cur["position"] = int(m.group(1)), int(m.group(2))
        elif cur and line.startswith("metadata:") and "description=" in line:
            desc = line.split("description=", 1)[1]
            parts = desc.rsplit(", ", 2)
            title = parts[0] if parts and parts[0] != "null" else None
            channel = parts[1] if len(parts) > 1 and parts[1] != "null" else None
            cur["title"], cur["channel"] = title, channel
    ranked = [s for s in sessions if s["title"]]
    ranked.sort(key=lambda s: {3: 0, 6: 1, 2: 2}.get(s["state"], 9))
    if not ranked:
        return None
    s = ranked[0]
    return {
        "app": PKG_NAMES.get(s["pkg"], s["pkg"]),
        "pkg": s["pkg"],
        "title": s["title"],
        "channel": s["channel"],
        "state": STATE_NAMES.get(s["state"], str(s["state"])),
        "position_s": (s["position"] or 0) // 1000,
    }


def foreground_pkg():
    out, ok = adb("shell", "dumpsys activity activities | grep -m1 ResumedActivity")
    m = re.search(r" ([\w.]+)/", out) if ok else None
    return m.group(1) if m else None


def disabled_pkgs():
    out, ok = adb("shell", "pm list packages -d")
    return {l[8:].strip() for l in out.splitlines() if l.startswith("package:")} if ok else set()


# --------------------------------------------------------------- actions ---
def press(key):
    return shell("input", "keyevent", KEYS[key])[1]


def stop_all_apps():
    for pkg in MEDIA_PKGS:
        shell("am", "force-stop", pkg)
    press("home")


def lockable_apps():
    """Installed apps it is safe to block: user-installed apps + a few Amazon extras."""
    out, ok = adb("shell", "pm list packages -3; echo ===; pm list packages -d; echo ===; pm list packages")
    if not ok:
        return []
    third, disabled, allp = [{l[8:].strip() for l in part.splitlines() if l.startswith("package:")}
                             for part in out.split("===")]
    pkgs = {p for p in third if ".overlay." not in p and p not in NEVER_LOCK}
    pkgs |= {p for p in EXTRA_LOCKABLE if p in allp}
    def name(p):
        return FRIENDLY.get(p) or p.split(".")[-1].replace("_", " ").title()
    return sorted(({"pkg": p, "name": name(p), "locked": p in disabled} for p in pkgs),
                  key=lambda a: a["name"].lower())


def set_pkg_locked(pkg, locked):
    if pkg not in {a["pkg"] for a in lockable_apps()}:
        raise ValueError("That app can't be blocked from here")
    if locked:
        shell("am", "force-stop", pkg)
        out, ok = shell("pm", "disable-user", "--user", "0", pkg)
    else:
        out, ok = shell("pm", "enable", pkg)
    if not (ok and "new state" in out):
        raise ValueError("TV refused: " + out.strip()[-200:])
    note(f"{FRIENDLY.get(pkg, pkg)} {'blocked' if locked else 'unblocked'}")
    return True


def set_app_locked(app, locked):
    pkg = APPS[app]["pkg"]
    if locked:
        shell("am", "force-stop", pkg)
        out, ok = shell("pm", "disable-user", "--user", "0", pkg)
    else:
        out, ok = shell("pm", "enable", pkg)
    return ok and "new state" in out, out.strip()


def lock_all_media():
    for pkg in MEDIA_PKGS:
        shell("am", "force-stop", pkg)
        shell("pm", "disable-user", "--user", "0", pkg)


def launch_app(app):
    return shell("monkey", "-p", APPS[app]["pkg"], "-c",
                 "android.intent.category.LEANBACK_LAUNCHER", "1")[1]


YT_ID = r"[A-Za-z0-9_-]{11}"


def parse_link(url):
    """Return (app, normalized_url, extra) or raise ValueError."""
    url = url.strip()
    if not re.match(r"^https?://", url):
        url = "https://" + url
    u = urllib.parse.urlparse(url)
    host = (u.hostname or "").lower().removeprefix("www.").removeprefix("m.")
    q = urllib.parse.parse_qs(u.query)

    if host in ("youtube.com", "music.youtube.com", "youtu.be", "youtube-nocookie.com"):
        vid = None
        if host == "youtu.be":
            vid = u.path.strip("/").split("/")[0]
        elif "v" in q:
            vid = q["v"][0]
        else:
            m = re.match(rf"^/(?:shorts|live|embed|v)/({YT_ID})", u.path)
            vid = m.group(1) if m else None
        params = {}
        if vid and re.fullmatch(YT_ID, vid):
            params["v"] = vid
        if "list" in q and re.fullmatch(r"[A-Za-z0-9_-]+", q["list"][0]):
            params["list"] = q["list"][0]
        if not params:
            raise ValueError("Couldn't find a YouTube video ID in that link")
        t = (q.get("t") or q.get("start") or [None])[0]
        if t and re.fullmatch(r"\d+s?", t):
            params["t"] = t.rstrip("s")
        return "youtube", "https://www.youtube.com/watch?" + urllib.parse.urlencode(params), None

    if host == "netflix.com":
        m = re.search(r"/(watch|title)/(\d+)", u.path)
        nid = m.group(2) if m else (q.get("jbv") or [None])[0]
        if not nid or not nid.isdigit():
            raise ValueError("Couldn't find a Netflix title ID in that link")
        kind = m.group(1) if m else "title"
        return "netflix", f"https://www.netflix.com/{kind}/{nid}", nid

    if host in ("hotstar.com", "jiohotstar.com"):
        return "hotstar", urllib.parse.urlunparse(u._replace(fragment="")), None

    raise ValueError("Only YouTube, Netflix and Hotstar links are supported")


KIDS_PKG = "com.home.adyatube"
KIDS_LIST_REMOTE = f"/sdcard/Android/data/{KIDS_PKG}/files/videos.json"
KIDS_LIST_LOCAL = os.path.join(HERE, "kids_videos.json")


def approved_videos():
    out = []
    for f in CONFIG["favorites"]:
        try:
            app, link, _ = parse_link(f["url"])
        except ValueError:
            continue
        vid = (urllib.parse.parse_qs(urllib.parse.urlparse(link).query).get("v") or [None])[0]
        if app == "youtube" and vid and vid not in {v["id"] for v in out}:
            out.append({"id": vid, "title": f["title"].split(" — ")[0],
                        "group": f.get("group") or SINGLE_GROUP})
    return out


def kids_app_installed():
    out, ok = adb("shell", f"pm list packages {KIDS_PKG}")
    return ok and f"package:{KIDS_PKG}" in out


def kids_payload():
    rows = []
    for v in approved_videos():
        r = next((r for r in rows if r["name"] == v["group"]), None)
        if not r:
            r = {"name": v["group"], "videos": []}
            rows.append(r)
        r["videos"].append({"id": v["id"], "title": v["title"]})
    chans = [{"id": c.get("id"), "handle": c.get("handle"), "name": c.get("title") or c.get("handle"),
              "avatar": c.get("avatar"), "videos": c.get("videos", []),
              "show": (c.get("match") or None) if c.get("playlist") else None}
             for c in CONFIG.get("channels", []) if c.get("videos")]
    return {"version": 2, "quality": int(CONFIG.get("kids_quality", 720)), "quiz": quiz_cfg(),
            "rows": rows, "channels": chans}


QUIZ_PATH = os.path.join(HERE, "quiz_stats.json")


def quiz_cfg():
    q = dict(DEFAULT_CONFIG["quiz"])
    q.update(CONFIG.get("quiz") or {})
    return q


def load_quiz_stats():
    try:
        with open(QUIZ_PATH) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {"days": {}, "math": None, "english": None}


def merge_quiz_stats(rep):
    """Keep the highest counts seen per day (the TV app reports running totals)."""
    if not isinstance(rep, dict):
        return
    st = load_quiz_stats()
    for day, v in (rep.get("days") or {}).items():
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(day)) or not isinstance(v, dict):
            continue
        cur = st["days"].get(day, {})
        if int(v.get("asked", 0)) >= int(cur.get("asked", 0)):
            st["days"][day] = {k: v[k] for k in ("asked", "correct", "math", "english") if k in v}
    if isinstance(rep.get("topics"), dict):
        st["topics"] = {str(k)[:20]: [int(v[0]), int(v[1])] for k, v in rep["topics"].items()
                        if isinstance(v, list) and len(v) == 2}
    if isinstance(rep.get("trophies"), dict):
        st["trophies"] = {str(k)[:20]: int(v) for k, v in rep["trophies"].items()}
    if isinstance(rep.get("recent"), list):
        st["recent_trophies"] = [{"k": str(t.get("k", ""))[:20], "d": str(t.get("d", ""))[:10], "n": str(t.get("n", ""))[:80]}
                                 for t in rep["recent"][-10:] if isinstance(t, dict)]
    if isinstance(rep.get("time"), dict) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(rep["time"].get("day", ""))):
        t = rep["time"]
        st["time"] = {"day": t["day"], "watched": int(t.get("watched") or 0),
                      "allowed": int(t["allowed"]) if t.get("allowed") is not None else None,
                      "unlocks": int(t.get("unlocks") or 0), "unlocked_min": int(t.get("unlocked_min") or 0)}
    if "all_mastered" in rep:
        st["all_mastered"] = bool(rep["all_mastered"])
    # Wrong-answer log: everything she ever missed, and whether it's still being practised.
    if isinstance(rep.get("review"), list):
        log = st.setdefault("wrong", {})
        now = time.time()
        seen = set()
        for it in rep["review"]:
            if not isinstance(it, dict) or not it.get("k"):
                continue
            k = str(it["k"])[:300]
            seen.add(k)
            e = log.get(k, {"first": now})
            if e.get("status") == "removed":
                continue
            e.update({"t": str(it.get("t", ""))[:200], "a": str(it.get("a", ""))[:60], "s": it.get("s"),
                      "w": max(int(it.get("w", 0)), int(e.get("w", 0))), "r": int(it.get("r", 0)),
                      "p": [str(x)[:40] for x in (it.get("p") or [])][-3:], "status": "practising", "seen": now})
            log[k] = e
        for k, e in log.items():   # dropped off the TV's list → she answered it right 3 times
            if e.get("status") == "practising" and k not in seen:
                e["status"] = "learned"; e["r"] = 3; e["learned"] = now
        if len(log) > 400:
            st["wrong"] = dict(sorted(log.items(), key=lambda kv: kv[1].get("seen", 0))[-400:])
    st["days"] = dict(sorted(st["days"].items())[-60:])
    with open(QUIZ_PATH, "w") as f:
        json.dump(st, f)


def quiz_summary():
    st = load_quiz_stats()
    today = datetime.now().strftime("%Y-%m-%d")
    t = st["days"].get(today, {})
    def sub(x):
        return {"asked": int((t.get(x) or {}).get("asked", 0)), "correct": int((t.get(x) or {}).get("correct", 0))}
    days = []
    for i in range(6, -1, -1):
        d = datetime.fromtimestamp(time.time() - i * 86400)
        k = d.strftime("%Y-%m-%d")
        v = st["days"].get(k, {})
        days.append({"label": "Today" if i == 0 else d.strftime("%a"),
                     "asked": int(v.get("asked", 0)), "correct": int(v.get("correct", 0))})
    return {"today": {"asked": int(t.get("asked", 0)), "correct": int(t.get("correct", 0)),
                      "math": sub("math"), "english": sub("english")},
            "days": days, "topics": st.get("topics", {}), "trophies": st.get("trophies", {}),
            "recent_trophies": st.get("recent_trophies", []), "all_mastered": bool(st.get("all_mastered")),
            "time": st.get("time") if (st.get("time") or {}).get("day") == today else None}


def quiz_wrong_list():
    log = load_quiz_stats().get("wrong", {})
    order = {"practising": 0, "learned": 1, "removed": 2}
    items = [dict(v, k=k) for k, v in log.items() if v.get("status") != "removed"]
    items.sort(key=lambda e: (order.get(e.get("status"), 3), -e.get("seen", 0)))
    return items[:150]


def quiz_review_remove(key):
    q = quiz_cfg()
    rm = [k for k in (q.get("review_remove") or []) if k != key] + [key]
    q["review_remove"] = rm[-300:]
    CONFIG["quiz"] = q
    save_config(CONFIG)
    st = load_quiz_stats()
    if key in st.get("wrong", {}):
        st["wrong"][key]["status"] = "removed"
        with open(QUIZ_PATH, "w") as f:
            json.dump(st, f)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return quiz_wrong_list()


QUIZ_TOPICS = ("count", "add", "sub", "tables", "puzzles", "phonics", "rhymes", "opposites", "spelling", "grammar", "custom")


def quiz_save(b):
    q = quiz_cfg()
    for k in ("subjects", "adaptive", "math_level", "english_level", "rev", "custom_per_quiz"):   # old settings
        q.pop(k, None)
    if "enabled" in b: q["enabled"] = bool(b["enabled"])
    if "speak" in b: q["speak"] = bool(b["speak"])
    if "every_min" in b: q["every_min"] = max(1, min(120, int(b["every_min"])))
    if "count" in b: q["count"] = max(1, min(10, int(b["count"])))
    if "pass_pct" in b: q["pass_pct"] = max(0, min(100, int(b["pass_pct"])))
    if "min_level" in b: q["min_level"] = max(1, min(6, int(b["min_level"])))
    if "max_level" in b: q["max_level"] = max(1, min(6, int(b["max_level"])))
    if q["min_level"] > q["max_level"]:
        raise ValueError("Easiest level can't be above hardest level")
    if "topics" in b:
        t = b["topics"] if isinstance(b["topics"], dict) else {}
        w = {k: max(0, min(5, int(t.get(k, 1)))) for k in QUIZ_TOPICS}
        if not any(w[k] for k in QUIZ_TOPICS if k != "custom"):
            raise ValueError("Turn on at least one topic")
        q["topics"] = w
    for k, lo, hi in (("entry_gap_min", 0, 240), ("daily_limit_min", 0, 600), ("unlock1_q", 1, 30), ("unlock1_min", 1, 120),
                      ("unlock_q", 1, 30), ("unlock_min", 1, 120), ("unlock_pass", 0, 99)):
        if k in b: q[k] = max(lo, min(hi, int(b[k])))
    if "milestones" in b:
        ms = b["milestones"]
        if isinstance(ms, str):
            ms = [x for x in re.split(r"[,\s]+", ms) if x]
        q["milestones"] = sorted({max(1, min(600, int(x))) for x in (ms or [])})[:10]
    if b.get("add_bonus"):                      # parent gives extra minutes for today only
        today = datetime.now().strftime("%Y-%m-%d")
        cur = q.get("time_bonus") or {}
        prev = int(cur.get("min", 0)) if cur.get("date") == today else 0
        q["time_bonus"] = {"date": today, "min": max(0, min(600, prev + int(b["add_bonus"])))}
    if b.get("mastery_reset"):
        q["mastery_reset"] = int(time.time())
    CONFIG["quiz"] = q
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return q


def quiz_custom(b):
    q = quiz_cfg()
    custom = list(q.get("custom") or [])
    if b.get("remove") is not None:
        custom.pop(int(b["remove"]))
    else:
        text = re.sub(r"[\x00-\x1f]", " ", str(b.get("q", ""))).strip()[:160]
        opts = [re.sub(r"[\x00-\x1f]", " ", str(o)).strip()[:40] for o in (b.get("options") or [])]
        opts = [o for o in opts if o]
        if not text or len(opts) < 2:
            raise ValueError("Write a question and at least 2 answers (first one is correct)")
        if len(set(opts)) != len(opts):
            raise ValueError("Answers must be different")
        subject = b.get("subject") if b.get("subject") in ("math", "english") else "custom"
        custom.append({"q": text, "options": opts[:3], "answer": 0, "subject": subject})
    q["custom"] = custom[-100:]
    CONFIG["quiz"] = q
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return q


def approved_ids():
    ids = {v["id"] for v in approved_videos()}
    for c in CONFIG.get("channels", []):
        ids |= {v["id"] for v in c.get("videos", [])}
    return ids


def sync_kids_list():
    """Push the approved list (rows + channels) to Kids Videos on the TV."""
    with open(KIDS_LIST_LOCAL, "w") as f:
        json.dump(kids_payload(), f, ensure_ascii=False)
    if not kids_app_installed():
        return False
    _, ok = adb("push", KIDS_LIST_LOCAL, KIDS_LIST_REMOTE, timeout=20)
    return ok


def play_link(url):
    app, link, extra = parse_link(url)
    pkg = APPS[app]["pkg"]
    if app == "youtube":
        vid = (urllib.parse.parse_qs(urllib.parse.urlparse(link).query).get("v") or [None])[0]
        if not vid:
            raise ValueError("That's a playlist link — add it on the Kids Videos page instead")
        if kids_app_installed():
            if KIDS_PKG in disabled_pkgs():
                raise ValueError("Kids Videos is blocked — unblock it first")
            added = False
            if vid not in approved_ids():
                # Sending a link from the dashboard counts as approving it.
                kids_add(f"https://www.youtube.com/watch?v={vid}")
                added = True
            sync_kids_list()
            press("wake")
            out, ok = shell("am", "start", "-n", f"{KIDS_PKG}/.MainActivity", "--es", "play", vid)
            if not ok or "Error" in out:
                raise ValueError("TV rejected the link: " + out.strip()[-200:])
            note(f"Played in Kids Videos{' (added to My videos)' if added else ''}: {link}")
            return {"app": "Kids Videos", "url": link, "added": added}
    if pkg in disabled_pkgs():
        raise ValueError(f"{APPS[app]['name']} is locked — unlock it first")
    press("wake")
    if app == "youtube":
        out, ok = shell("am", "start", "-a", "android.intent.action.VIEW", "-d", link, pkg)
    elif app == "netflix":
        out, ok = shell("am", "start", "-a", "android.intent.action.VIEW",
                        "-n", "com.netflix.ninja/.MainActivity", "-f", "0x10808000",
                        "-d", link, "-e", "source", "30", "-e", "amzn_deeplink_data", extra)
    else:
        out, ok = shell("am", "start", "-a", "android.intent.action.VIEW", "-d", link, pkg)
    if not ok or "Error" in out:
        raise ValueError("TV rejected the link: " + out.strip()[-200:])
    note(f"Played on {APPS[app]['name']}: {link}")
    return {"app": APPS[app]["name"], "url": link}


MSG_ACTIVITY = "com.home.tvmsg/.MsgActivity"


def send_message(text, title="", secs=30, speak=True):
    text = re.sub(r"[\x00-\x1f]", " ", str(text)).strip()[:300]
    title = re.sub(r"[\x00-\x1f]", " ", str(title)).strip()[:60]
    if not text:
        raise ValueError("Type a message first")
    secs = max(0, min(int(secs), 600))
    press("wake")
    args = ["am", "start", "-n", MSG_ACTIVITY, "--es", "text", text,
            "--ei", "secs", secs, "--ez", "speak", "true" if speak else "false"]
    if title:
        args += ["--es", "title", title]
    out, ok = shell(*args)
    if not ok or "Error" in out:
        raise ValueError("TV Message app missing? " + out.strip()[-200:])
    note(f"Message shown: {text}")
    return True


SINGLE_GROUP = "My videos"


def yt_get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "en"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", "replace")


def fetch_playlist(pid):
    """Return (playlist_title, [(video_id, title), ...]) — first ~100 videos, no API key needed."""
    html = yt_get(f"https://www.youtube.com/playlist?list={pid}")
    m = re.search(r"var ytInitialData = (\{.*?\});</script>", html)
    if not m:
        raise ValueError("Couldn't read that playlist (is it private?)")
    data = json.loads(m.group(1))
    title = (data.get("metadata", {}).get("playlistMetadataRenderer", {}).get("title")
             or "Playlist")
    vids, seen = [], set()

    def add(vid, t):
        if vid and re.fullmatch(YT_ID, vid) and vid not in seen and t:
            seen.add(vid)
            vids.append((vid, t))

    def walk(o):
        if isinstance(o, dict):
            lv = o.get("lockupViewModel")
            if isinstance(lv, dict) and str(lv.get("contentType", "")).endswith("VIDEO"):
                add(lv.get("contentId"), lv.get("metadata", {}).get("lockupMetadataViewModel", {})
                    .get("title", {}).get("content"))
            pv = o.get("playlistVideoRenderer")
            if isinstance(pv, dict) and pv.get("isPlayable", True):
                add(pv.get("videoId"), "".join(x.get("text", "") for x in pv.get("title", {}).get("runs", [])))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(data)
    if not vids:  # fallback: RSS feed (latest 15)
        try:
            xml = yt_get(f"https://www.youtube.com/feeds/videos.xml?playlist_id={pid}")
            for vid, t in re.findall(r"<yt:videoId>([^<]+)</yt:videoId>\s*<yt:channelId>[^<]*</yt:channelId>\s*<title>([^<]+)</title>", xml):
                add(vid, t)
        except Exception:
            pass
    if not vids:
        raise ValueError(f"Playlist “{title}” has no playable videos")
    return title, vids


def extract_videos(data):
    """All (video_id, title) pairs in a YouTube ytInitialData blob, in page order."""
    vids, seen = [], set()

    def add(vid, t):
        if vid and re.fullmatch(YT_ID, vid) and vid not in seen and t:
            seen.add(vid)
            vids.append((vid, t))

    def walk(o):
        if isinstance(o, dict):
            lv = o.get("lockupViewModel")
            if isinstance(lv, dict) and str(lv.get("contentType", "")).endswith("VIDEO"):
                add(lv.get("contentId"), lv.get("metadata", {}).get("lockupMetadataViewModel", {})
                    .get("title", {}).get("content"))
            for key in ("videoRenderer", "playlistVideoRenderer", "gridVideoRenderer"):
                vr = o.get(key)
                if isinstance(vr, dict) and vr.get("isPlayable", True):
                    t = vr.get("title", {})
                    add(vr.get("videoId"), t.get("simpleText") or "".join(x.get("text", "") for x in t.get("runs", [])))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(data)
    return vids


EP_RE = re.compile(r"\bEp(?:isode)?\.?\s*0*(\d{1,4})\b", re.I)
PLAYLIST_REFRESH = 24 * 3600   # full-playlist channels are re-read once a day (≈15 requests each)


def _page_items(o, vids, toks):
    """Collect (video_id, title) pairs and browse-continuation tokens from a ytInitialData / browse blob."""
    if isinstance(o, dict):
        lv = o.get("lockupViewModel")
        if isinstance(lv, dict) and str(lv.get("contentType", "")).endswith("VIDEO"):
            vids.append((lv.get("contentId"), lv.get("metadata", {}).get("lockupMetadataViewModel", {})
                         .get("title", {}).get("content")))
        pv = o.get("playlistVideoRenderer")
        if isinstance(pv, dict) and pv.get("isPlayable", True):
            vids.append((pv.get("videoId"), "".join(x.get("text", "") for x in pv.get("title", {}).get("runs", []))))
        cc = o.get("continuationCommand")
        if isinstance(cc, dict) and cc.get("token") and cc.get("request") == "CONTINUATION_REQUEST_TYPE_BROWSE":
            toks.append(cc["token"])
        for v in o.values():
            _page_items(v, vids, toks)
    elif isinstance(o, list):
        for v in o:
            _page_items(v, vids, toks)


def fetch_playlist_all(pid, max_pages=80):
    """Every video in a playlist (pages of 100 via YouTube's browse continuation; no API key)."""
    html = yt_get(f"https://www.youtube.com/playlist?list={pid}")
    m = re.search(r"var ytInitialData = (\{.*?\});</script>", html)
    key = re.search(r'"INNERTUBE_API_KEY":"([^"]+)"', html)
    ver = re.search(r'"INNERTUBE_CLIENT_VERSION":"([^"]+)"', html)
    if not (m and key and ver):
        raise ValueError("Couldn't read that playlist (is it private?)")
    vids, toks = [], []
    _page_items(json.loads(m.group(1)), vids, toks)
    pages = 1
    while toks and pages < max_pages:
        body = json.dumps({"context": {"client": {"clientName": "WEB", "clientVersion": ver.group(1), "hl": "en"}},
                           "continuation": toks[0]}).encode()
        req = urllib.request.Request(f"https://www.youtube.com/youtubei/v1/browse?key={key.group(1)}&prettyPrint=false",
                                     data=body, headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "en",
                                                         "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as r:
            page = json.loads(r.read())
        got, toks = [], []
        _page_items(page, got, toks)
        if not got:
            break
        vids += got
        pages += 1
        time.sleep(0.3)
    return vids


def fetch_show(pid, match=""):
    """Playlist videos whose title contains `match`, one per episode number, sorted by episode."""
    want = str(match or "").casefold().strip()
    by_ep, extra, seen = {}, [], set()
    for vid, t in fetch_playlist_all(pid):
        if not (vid and t and re.fullmatch(YT_ID, vid)) or vid in seen:
            continue
        if want and want not in t.casefold():
            continue
        seen.add(vid)
        m = EP_RE.search(t)
        if m:
            by_ep.setdefault(int(m.group(1)), {"id": vid, "title": t[:150], "ep": int(m.group(1))})
        else:
            extra.append({"id": vid, "title": t[:150]})
    out = [by_ep[k] for k in sorted(by_ep)] + extra
    if not out:
        raise ValueError("No matching videos in that playlist")
    return out


def channel_path(text):
    """Accept @handle, a channel URL, or a channel ID → URL path like '@Bluey' or 'channel/UC…'."""
    t = str(text).strip()
    m = re.search(r"youtube\.com/(@[\w.\-]+|channel/UC[\w-]{22}|c/[\w.\-]+|user/[\w.\-]+)", t)
    if m:
        return m.group(1)
    if re.fullmatch(r"@[\w.\-]{3,40}", t):
        return t
    if re.fullmatch(r"UC[\w-]{22}", t):
        return "channel/" + t
    raise ValueError("Paste a channel link like youtube.com/@Bluey or an @handle")


def fetch_channel(text, limit=30):
    path = channel_path(text)
    html = yt_get(f"https://www.youtube.com/{path}/videos")
    m = re.search(r"var ytInitialData = (\{.*?\});</script>", html)
    if not m:
        raise ValueError("Couldn't read that channel")
    data = json.loads(m.group(1))
    md = data.get("metadata", {}).get("channelMetadataRenderer", {})
    if not md.get("externalId"):
        raise ValueError("Channel not found")
    thumbs = md.get("avatar", {}).get("thumbnails", [])
    vids = extract_videos(data)[:limit]
    if not vids:
        raise ValueError(f"{md.get('title')} has no videos to show")
    handle = (re.search(r'"vanityChannelUrl":"https?://www\.youtube\.com/(@[^"]+)"', html) or [None, path])[1]
    return {"id": md["externalId"], "handle": handle, "title": md.get("title", path),
            "avatar": thumbs[0]["url"] if thumbs else None,
            "videos": [{"id": v, "title": t[:150]} for v, t in vids], "fetched": time.time()}


def channels_add(text):
    CONFIG.setdefault("channels", [])
    added, errors = [], []
    for line in [l.strip() for l in re.split(r"[\s,]+", str(text)) if l.strip()][:30]:
        try:
            ch = fetch_channel(line)
            if any(c.get("id") == ch["id"] for c in CONFIG["channels"]):
                errors.append(f"{ch['title']} — already added")
                continue
            CONFIG["channels"].append(ch)
            added.append(ch["title"])
        except Exception as e:
            errors.append(f"{line[:60]} — {e}")
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return {"added": added, "errors": errors}


def refresh_one(c, force=False):
    """Fresh copy of channel `c`. A channel with a `playlist` shows only that playlist's videos
    (filtered by `match`, e.g. every "Mere Sai" episode) instead of its latest uploads."""
    fresh = fetch_channel(c["id"] if c.get("id") else c["handle"])
    fresh["handle"] = c.get("handle") or fresh["handle"]
    if c.get("playlist"):
        fresh["playlist"], fresh["match"] = c["playlist"], c.get("match", "")
        if not force and c.get("videos") and time.time() - c.get("pl_fetched", 0) < PLAYLIST_REFRESH:
            fresh["videos"], fresh["pl_fetched"] = c["videos"], c["pl_fetched"]
        else:
            try:
                fresh["videos"], fresh["pl_fetched"] = fetch_show(c["playlist"], c.get("match")), time.time()
            except Exception as e:
                if not c.get("videos"):
                    raise
                note(f"Playlist refresh failed for {c.get('title')}: {e}")
                fresh["videos"], fresh["pl_fetched"] = c["videos"], c.get("pl_fetched", 0)
    return fresh


def channels_refresh():
    for i, c in enumerate(list(CONFIG.get("channels", []))):
        try:
            CONFIG["channels"][i] = refresh_one(c)
        except Exception as e:
            note(f"Channel refresh failed for {c.get('title')}: {e}")
    save_config(CONFIG)
    sync_kids_list()


def channels_public():
    return [{"id": c.get("id"), "handle": c.get("handle"), "title": c.get("title"), "avatar": c.get("avatar"),
             "count": len(c.get("videos", [])), "fetched": c.get("fetched"),
             "playlist": c.get("playlist"), "match": c.get("match"),
             "videos": c.get("videos", [])[:8]} for c in CONFIG.get("channels", [])]


def channels_edit(b):
    chans = CONFIG.setdefault("channels", [])
    i = next((k for k, c in enumerate(chans) if c.get("id") == b.get("id")), None)
    if i is None:
        raise ValueError("Channel not found")
    if b.get("action") == "remove":
        chans.pop(i)
    elif b.get("action") == "move":
        j = i + int(b.get("dir", 0))
        if 0 <= j < len(chans):
            chans[i], chans[j] = chans[j], chans[i]
    elif b.get("action") == "source":
        # show only one playlist's videos on this channel (empty playlist = back to latest uploads)
        link = str(b.get("playlist") or "").strip()
        c = dict(chans[i])
        if link:
            m = re.search(r"(?:list=)?((?:PL|UU|OL|FL)[\w-]{10,})", link)
            if not m:
                raise ValueError("Paste a playlist link (it has list=PL… in it)")
            c["playlist"], c["match"] = m.group(1), re.sub(r"[\x00-\x1f]", " ", str(b.get("match") or "")).strip()[:60]
        else:
            for k in ("playlist", "match", "pl_fetched"):
                c.pop(k, None)
        chans[i] = refresh_one(c, force=True)
    else:
        raise ValueError("Unknown action")
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return channels_public()


def video_id_of(url):
    try:
        app, link, _ = parse_link(url)
    except ValueError:
        return None
    if app != "youtube":
        return None
    return (urllib.parse.parse_qs(urllib.parse.urlparse(link).query).get("v") or [None])[0]


def kids_list():
    out = []
    for f in CONFIG["favorites"]:
        vid = video_id_of(f["url"])
        if vid:
            out.append({"id": vid, "title": f["title"], "group": f.get("group") or SINGLE_GROUP,
                        "url": f["url"]})
    return out


def kids_add(text, group=""):
    """Add many links (one per line). Videos go to `group` (or "My videos"); playlists become their own group."""
    group = re.sub(r"[\x00-\x1f]", " ", str(group)).strip()[:60]
    have = {video_id_of(f["url"]) for f in CONFIG["favorites"]}
    added, skipped, errors, pending = 0, 0, [], []
    lines = [l.strip() for l in re.split(r"[\s,]+", str(text)) if l.strip()][:200]
    for line in lines:
        try:
            u = urllib.parse.urlparse(line if re.match(r"^https?://", line) else "https://" + line)
            q = urllib.parse.parse_qs(u.query)
            host = (u.hostname or "").lower().removeprefix("www.").removeprefix("m.")
            is_playlist = (host.endswith("youtube.com") and "list" in q
                           and (u.path.startswith("/playlist") or "v" not in q))
            if is_playlist:
                pid = q["list"][0]
                if not re.fullmatch(r"[A-Za-z0-9_-]{10,64}", pid):
                    raise ValueError("bad playlist id")
                ptitle, vids = fetch_playlist(pid)
                g = group or ptitle[:60]
                for vid, t in vids:
                    if vid in have:
                        skipped += 1
                        continue
                    have.add(vid)
                    CONFIG["favorites"].append({"title": t[:150], "group": g,
                                                "url": f"https://www.youtube.com/watch?v={vid}"})
                    added += 1
            else:
                if not (host.endswith("youtube.com") or host == "youtu.be"):
                    raise ValueError("not a YouTube link")
                app, link, _ = parse_link(line)
                vid = video_id_of(link)
                if not vid:
                    raise ValueError("no video id")
                if vid in have:
                    skipped += 1
                    continue
                have.add(vid)
                pending.append({"url": link, "group": group or SINGLE_GROUP})
        except Exception as e:
            errors.append(f"{line[:60]} — {e}")
    if pending:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(8) as ex:
            titles = list(ex.map(lambda p: fetch_title(p["url"]), pending))
        for p, t in zip(pending, titles):
            CONFIG["favorites"].append({"title": (t or p["url"])[:150], "group": p["group"], "url": p["url"]})
            added += 1
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return {"added": added, "skipped": skipped, "errors": errors}


def kids_edit(b):
    favs = CONFIG["favorites"]
    idx = {video_id_of(f["url"]): i for i, f in enumerate(favs)}
    action = b.get("action")
    if action == "remove":
        vid = b.get("id")
        if vid not in idx:
            raise ValueError("Video not found")
        favs.pop(idx[vid])
    elif action == "remove_group":
        g = b.get("group")
        CONFIG["favorites"] = [f for f in favs
                               if not (video_id_of(f["url"]) and (f.get("group") or SINGLE_GROUP) == g)]
    elif action == "move":
        vid, d = b.get("id"), int(b.get("dir", 0))
        if vid not in idx or d not in (-1, 1):
            raise ValueError("Bad move")
        i = idx[vid]
        g = favs[i].get("group") or SINGLE_GROUP
        j = i + d
        while 0 <= j < len(favs) and not (video_id_of(favs[j]["url"])
                                          and (favs[j].get("group") or SINGLE_GROUP) == g):
            j += d
        if 0 <= j < len(favs):
            favs[i], favs[j] = favs[j], favs[i]
    elif action == "rename_group":
        old, new = b.get("group"), re.sub(r"[\x00-\x1f]", " ", str(b.get("to", ""))).strip()[:60]
        if not new:
            raise ValueError("Name can't be empty")
        for f in favs:
            if video_id_of(f["url"]) and (f.get("group") or SINGLE_GROUP) == old:
                f["group"] = new
    elif action == "move_group":
        g, d = b.get("group"), int(b.get("dir", 0))
        order = []
        for f in favs:
            gg = f.get("group") or SINGLE_GROUP
            if video_id_of(f["url"]) and gg not in order:
                order.append(gg)
        if g not in order or d not in (-1, 1):
            raise ValueError("Bad move")
        i = order.index(g)
        j = i + d
        if 0 <= j < len(order):
            order[i], order[j] = order[j], order[i]
            rank = {x: k for k, x in enumerate(order)}
            yt = sorted((f for f in favs if video_id_of(f["url"])),
                        key=lambda f: rank[f.get("group") or SINGLE_GROUP])
            CONFIG["favorites"] = yt + [f for f in favs if not video_id_of(f["url"])]
    else:
        raise ValueError("Unknown action")
    save_config(CONFIG)
    threading.Thread(target=sync_kids_list, daemon=True).start()
    return kids_list()


def fetch_title(url):
    try:
        app, link, _ = parse_link(url)
    except ValueError:
        return None
    if app != "youtube":
        return None
    try:
        api = "https://www.youtube.com/oembed?format=json&url=" + urllib.parse.quote(link, safe="")
        with urllib.request.urlopen(api, timeout=6) as r:
            d = json.load(r)
        return f"{d['title']} — {d['author_name']}"
    except Exception:
        return None


# ------------------------------------------------------------- schedules ---
def in_bedtime(now=None):
    b = CONFIG.get("bedtime") or {}
    if not b.get("enabled"):
        return False
    now = now or datetime.now()
    cur = now.hour * 60 + now.minute
    sh, sm = map(int, b["start"].split(":"))
    eh, em = map(int, b["end"].split(":"))
    s, e = sh * 60 + sm, eh * 60 + em
    return (s <= cur < e) if s <= e else (cur >= s or cur < e)


def log_history(np):
    rec = {"ts": time.time(), "app": np["app"], "title": np["title"], "channel": np["channel"]}
    with open(HISTORY_PATH, "a") as f:
        f.write(json.dumps(rec) + "\n")


def read_history(limit=100):
    if not os.path.exists(HISTORY_PATH):
        return []
    with open(HISTORY_PATH) as f:
        lines = f.readlines()[-limit:]
    return [json.loads(l) for l in reversed(lines) if l.strip()]


def monitor_loop():
    last_sync = 0
    last_channels = time.time()
    last_watch = 0
    while True:
        try:
            connected = ensure_connected()
            if time.time() - last_channels > 6 * 3600 and CONFIG.get("channels"):
                last_channels = time.time()
                threading.Thread(target=channels_refresh, daemon=True).start()
            if connected and time.time() - last_watch > 30:
                last_watch = time.time()
                kids_watch_sync()
            if connected and time.time() - last_sync > 600:
                sync_kids_list()
                last_sync = time.time()
            fg = foreground_pkg() if connected else None
            np = now_playing(fg) if connected else None
            with lock:
                state["last_status"] = {"connected": connected, "now": np, "foreground": fg,
                                        "checked": time.time()}
                if np and np["state"] in ("playing", "buffering") and np["title"] != state["last_title"]:
                    state["last_title"] = np["title"]
                    log_history(np)
                timer_end = state["timer_end"]
            playing = bool(np and np["state"] in ("playing", "buffering"))

            if (connected and timer_end and not state.get("warned")
                    and 0 < timer_end - time.time() <= 300):
                state["warned"] = True
                left = max(1, round((timer_end - time.time()) / 60))
                try:
                    send_message(f"{left} more minute{'s' if left > 1 else ''} of TV time left!",
                                 "⏰ Almost time", secs=12)
                except ValueError:
                    pass

            if connected and timer_end and time.time() >= timer_end:
                with lock:
                    state["timer_end"] = None
                    do_lock = state["timer_lock"]
                stop_all_apps()
                try:
                    send_message("TV time is over for now. Great job! 🌟", "⏰ Time's up", secs=60)
                except ValueError:
                    pass
                if do_lock:
                    lock_all_media()
                note("Screen time is up — stopped playback" + (" and locked apps" if do_lock else ""))

            if connected and in_bedtime() and (playing or (fg in MEDIA_PKGS)):
                stop_all_apps()
                if CONFIG["bedtime"].get("lock"):
                    lock_all_media()
                try:
                    send_message("It's bedtime. Good night, sleep well! 🌙", "🌙 Bedtime", secs=60)
                except ValueError:
                    pass
                note("Bedtime — stopped playback")
        except Exception as e:  # keep the monitor alive no matter what
            note(f"Monitor error: {e}")
        time.sleep(10)


# ------------------------------------------------------------------ http ---
class Handler(BaseHTTPRequestHandler):
    server_version = "FireTVRemote/1.0"

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _authed(self):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        tok = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        return hmac.compare_digest(tok.encode(), CONFIG["token"].encode())

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 100_000:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(INDEX_PATH, "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if path in ("/kids", "/kids.html"):
            with open(os.path.join(HERE, "kids.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if not self._authed():
            return self._send(401, {"error": "Wrong or missing PIN link"})
        if path == "/app.apk":
            apk = os.path.join(HERE, "phone", "adya-remote.apk")
            if not os.path.exists(apk):
                return self._send(404, {"error": "Phone app not built yet"})
            with open(apk, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Disposition", f'attachment; filename="{os.path.basename(apk)}"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path == "/api/status":
            with lock:
                st = dict(state["last_status"])
                st["timer_end"] = state["timer_end"]
                st["timer_lock"] = state["timer_lock"]
                st["events"] = list(state["events"][:8])
            st["bedtime"] = CONFIG["bedtime"]
            st["watch"] = watch_summary()
            st["quiz"] = quiz_summary()
            st["in_bedtime"] = in_bedtime()
            dis = disabled_pkgs() if st.get("connected") else set()
            st["apps"] = {k: {"name": a["name"], "locked": a["pkg"] in dis} for k, a in APPS.items()}
            st["now_ts"] = time.time()
            return self._send(200, st)
        if path == "/api/screen.png":
            png, ok = adb("exec-out", "screencap", "-p", binary=True, timeout=15)
            if not ok or not png.startswith(b"\x89PNG"):
                return self._send(502, {"error": "Screenshot failed"})
            return self._send(200, png, "image/png")
        if path == "/api/favorites":
            return self._send(200, CONFIG["favorites"])
        if path == "/api/kids":
            return self._send(200, kids_list())
        if path == "/api/channels":
            return self._send(200, channels_public())
        if path == "/api/kids/quality":
            return self._send(200, {"quality": int(CONFIG.get("kids_quality", 720))})
        if path == "/api/quiz":
            return self._send(200, {"config": quiz_cfg(), "stats": quiz_summary(), "wrong": quiz_wrong_list()})
        if path == "/api/allapps":
            return self._send(200, lockable_apps())
        if path == "/api/history":
            return self._send(200, read_history())
        return self._send(404, {"error": "Not found"})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if not self._authed():
            return self._send(401, {"error": "Wrong or missing PIN link"})
        try:
            b = self._body()
            if path == "/api/key":
                if b.get("key") not in KEYS:
                    raise ValueError("Unknown key")
                return self._send(200, {"ok": press(b["key"])})
            if path == "/api/play":
                return self._send(200, {"ok": True, **play_link(str(b.get("url", "")))})
            if path == "/api/message":
                return self._send(200, {"ok": send_message(
                    b.get("text", ""), b.get("title", ""), b.get("secs", 30), b.get("speak", True))})
            if path == "/api/text":
                txt = re.sub(r"[^A-Za-z0-9 .,'-]", "", str(b.get("text", "")))[:100]
                return self._send(200, {"ok": shell("input", "text", txt.replace(" ", "%s"))[1]})
            if path == "/api/app":
                app, action = b.get("app"), b.get("action")
                if app not in APPS:
                    raise ValueError("Unknown app")
                if action == "launch":
                    ok = launch_app(app)
                elif action == "stop":
                    ok = shell("am", "force-stop", APPS[app]["pkg"])[1]
                    press("home")
                elif action in ("lock", "unlock"):
                    ok, msg = set_app_locked(app, action == "lock")
                    if not ok:
                        raise ValueError(f"TV refused: {msg[-200:]}")
                    note(f"{APPS[app]['name']} {action}ed")
                else:
                    raise ValueError("Unknown action")
                return self._send(200, {"ok": ok})
            if path == "/api/kids/add":
                return self._send(200, kids_add(b.get("text", ""), b.get("group", "")))
            if path == "/api/kids/edit":
                return self._send(200, kids_edit(b))
            if path == "/api/quiz":
                return self._send(200, {"config": quiz_save(b), "stats": quiz_summary(), "wrong": quiz_wrong_list()})
            if path == "/api/quiz/review-remove":
                return self._send(200, {"wrong": quiz_review_remove(str(b.get("key", ""))[:300])})
            if path == "/api/quiz/custom":
                return self._send(200, {"config": quiz_custom(b)})
            if path == "/api/quiz/now":
                if KIDS_PKG in disabled_pkgs():
                    raise ValueError("Kids Videos is blocked — unblock it first")
                sync_kids_list()
                press("wake")
                out, ok = shell("am", "start", "-n", f"{KIDS_PKG}/.QuizActivity")
                if not ok or "Error" in out:
                    raise ValueError("TV rejected it: " + out.strip()[-200:])
                note("Quiz started from dashboard")
                return self._send(200, {"ok": True})
            if path == "/api/quiz/skip":           # parent: close Kids Quiz and reset the 10-minute timer
                out, ok = shell("am", "start", "-n", f"{KIDS_PKG}/.QuizActivity", "--ez", "skip", "true")
                if not ok or "Error" in out:
                    raise ValueError("TV rejected it: " + out.strip()[-200:])
                note("Kids Quiz skipped from dashboard")
                return self._send(200, {"ok": True})
            if path == "/api/kids/quality":
                q = int(b.get("quality", 720))
                if q not in (480, 720, 1080):
                    raise ValueError("Pick 480, 720 or 1080")
                CONFIG["kids_quality"] = q
                save_config(CONFIG)
                threading.Thread(target=sync_kids_list, daemon=True).start()
                note(f"Kids Videos max quality set to {q}p")
                return self._send(200, {"ok": True, "quality": q})
            if path == "/api/channels/add":
                return self._send(200, channels_add(b.get("text", "")))
            if path == "/api/channels/edit":
                return self._send(200, channels_edit(b))
            if path == "/api/channels/refresh":
                channels_refresh()
                return self._send(200, channels_public())
            if path == "/api/block":
                return self._send(200, {"ok": set_pkg_locked(str(b.get("pkg", "")), bool(b.get("block")))})
            if path == "/api/stopall":
                stop_all_apps()
                note("Stopped everything")
                return self._send(200, {"ok": True})
            if path == "/api/timer":
                mins = float(b.get("minutes", 0))
                with lock:
                    state["timer_end"] = time.time() + mins * 60 if mins > 0 else None
                    state["timer_lock"] = bool(b.get("lock", True))
                    state["warned"] = mins <= 5
                note(f"Screen time set: {mins:g} min" if mins > 0 else "Screen time timer cancelled")
                return self._send(200, {"ok": True})
            if path == "/api/bedtime":
                for k in ("start", "end"):
                    if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", str(b.get(k, ""))):
                        raise ValueError("Time must be HH:MM")
                CONFIG["bedtime"] = {"enabled": bool(b.get("enabled")), "start": b["start"],
                                     "end": b["end"], "lock": bool(b.get("lock"))}
                save_config(CONFIG)
                note("Bedtime " + (f"on: {b['start']}–{b['end']}" if b.get("enabled") else "off"))
                return self._send(200, {"ok": True})
            if path == "/api/favorites":
                if b.get("remove") is not None:
                    i = int(b["remove"])
                    CONFIG["favorites"].pop(i)
                else:
                    url = str(b.get("url", "")).strip()
                    parse_link(url)  # validate
                    title = str(b.get("title") or "").strip()[:150] or fetch_title(url) or url
                    CONFIG["favorites"].append({"title": title, "url": url})
                save_config(CONFIG)
                threading.Thread(target=sync_kids_list, daemon=True).start()
                return self._send(200, CONFIG["favorites"])
            return self._send(404, {"error": "Not found"})
        except (ValueError, IndexError, KeyError, json.JSONDecodeError) as e:
            return self._send(400, {"error": str(e)})


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.168.0.1", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def main():
    threading.Thread(target=monitor_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    t = CONFIG["token"]
    print("\nFire TV parental remote is running.")
    print(f"  On this Mac:   http://localhost:{PORT}/?t={t}")
    print(f"  On your phone: http://{lan_ip()}:{PORT}/?t={t}")
    print("Keep this link private — it is the PIN.\n", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
