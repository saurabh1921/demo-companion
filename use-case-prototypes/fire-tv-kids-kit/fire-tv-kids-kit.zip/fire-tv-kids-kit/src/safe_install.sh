#!/bin/bash
# Install an APK on the Fire TV only when nobody is using it.
# Usage: ./safe_install.sh [--dry-run] path/to/app.apk
DEV="${FIRETV:-$(python3 -c "import json;print(json.load(open('$(dirname "$0")/config.json'))['device'])")}"
DRY=0; [ "${1:-}" = "--dry-run" ] && { DRY=1; shift; }
APK="$1"
PKG=$(~/Library/Android/sdk/build-tools/34.0.0/aapt2 dump packagename "$APK" | tr -d '\r\n')
busy() {
  local fg playing
  fg=$(adb -s "$DEV" shell "dumpsys activity activities | grep -m1 ResumedActivity" | sed -E 's/.* ([a-zA-Z0-9_.]+)\/.*/\1/' | tr -d '\r\n')
  playing=$(adb -s "$DEV" shell "dumpsys media_session | grep -c 'state=PlaybackState {state=3'" | tr -d '\r\n')
  [ -z "$fg" ] && { echo "can't read TV state"; return 0; }
  [ "$fg" = "$PKG" ] && { echo "$PKG is open on the TV"; return 0; }
  [ "${playing:-0}" != "0" ] && { echo "something is playing on the TV"; return 0; }
  return 1
}
for i in 1 2; do
  if why=$(busy); then echo "REFUSED: $why. Try later."; exit 2; fi
  [ $i = 1 ] && sleep 3
done
if [ $DRY = 1 ]; then echo "DRY RUN: TV is idle, would install $PKG"; exit 0; fi
adb -s "$DEV" install -r "$APK"
