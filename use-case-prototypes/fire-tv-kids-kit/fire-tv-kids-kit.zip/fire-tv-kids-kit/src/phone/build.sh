#!/bin/bash
# Builds adya-remote.apk (phone app) with the current Mac IP + PIN baked in as defaults.
set -euo pipefail
cd "$(dirname "$0")"
SDK="$HOME/Library/Android/sdk"; BT="$SDK/build-tools/34.0.0"; PLAT="$SDK/platforms/android-34/android.jar"
export PATH="/opt/homebrew/opt/openjdk@17/bin:$PATH"
IP="${REMOTE_IP:-$(ipconfig getifaddr en0 || echo 0.0.0.0)}"
PIN=$(python3 -c "import json;print(json.load(open('../config.json'))['token'])")
PORT="${FIRETV_PORT:-8765}"
rm -rf build && mkdir -p build/classes build/res build/src
cp -R src/. build/src/
sed -i '' -e "s#@@IP@@#$IP#" -e "s#@@PORT@@#$PORT#" -e "s#@@PIN@@#$PIN#" build/src/com/home/adyaremote/MainActivity.java
"$BT/aapt2" compile --dir res -o build/res/res.zip
"$BT/aapt2" link -o build/base.apk -I "$PLAT" --manifest AndroidManifest.xml \
  --min-sdk-version 24 --target-sdk-version 34 --version-code "$(( $(date +%s) / 60 ))" --version-name "1.$(date +%m%d.%H%M)" build/res/res.zip
javac -nowarn -source 8 -target 8 -classpath "$PLAT" -d build/classes $(find build/src -name '*.java') 2>&1 | grep -vE "bootstrap classpath|^warning|^1 warning|JAVA_TOOL|^Note" || true
"$BT/d8" --min-api 24 --lib "$PLAT" --output build $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk && (cd build && zip -q unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
"$BT/apksigner" sign --ks ../tvmsg/debug.keystore --ks-pass pass:android --out adya-remote.apk build/aligned.apk
echo "Built $(pwd)/adya-remote.apk  (defaults: http://$IP:$PORT, PIN baked in)"
