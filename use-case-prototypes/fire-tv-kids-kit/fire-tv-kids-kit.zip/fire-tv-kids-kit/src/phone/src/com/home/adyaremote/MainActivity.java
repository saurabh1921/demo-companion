package com.home.adyaremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Phone remote for the Fire TV parental dashboard.
 * Opens http://IP:PORT/?t=PIN in a WebView; the ⚙ button changes IP / port / PIN.
 * "Find server" scans the phone's Wi-Fi subnet for the dashboard when the Mac's IP changes.
 */
public class MainActivity extends Activity {
    // Defaults baked in at build time (build.sh replaces these from config.json).
    static final String DEF_IP = "@@IP@@";
    static final String DEF_PORT = "@@PORT@@";
    static final String DEF_PIN = "@@PIN@@";

    private SharedPreferences prefs;
    private FrameLayout root;
    private WebView web;
    private View form;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean autoScanned = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        if (!prefs.contains("ip")) {
            prefs.edit().putString("ip", DEF_IP).putString("port", DEF_PORT).putString("pin", DEF_PIN).apply();
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#FFF8EC"));
        setContentView(root);
        showWeb();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private String base() {
        return "http://" + prefs.getString("ip", DEF_IP).trim() + ":" + prefs.getString("port", DEF_PORT).trim();
    }

    private void showWeb() {
        root.removeAllViews();
        form = null;
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    if (!autoScanned) {
                        autoScanned = true;
                        showSettings("Can't reach " + base() + ". Searching the Wi-Fi for the dashboard…");
                        findServer();
                        return;
                    }
                    showSettings("Can't reach the dashboard at " + base()
                            + ".\nIs the Mac switched on and on the same Wi-Fi? Tap \"Find server\" or fix the IP below.");
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // Stay inside the app for the dashboard; block anything else.
                Uri u = req.getUrl();
                String ip = prefs.getString("ip", DEF_IP).trim();
                return !(ip.equals(u.getHost()));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(); }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(); }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.cancel(); }
                        }).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText in = new EditText(MainActivity.this);
                in.setSingleLine(true);
                if (def != null) { in.setText(def); in.setSelection(def.length()); }
                FrameLayout wrap = new FrameLayout(MainActivity.this);
                wrap.setPadding(dp(20), dp(6), dp(20), 0);
                wrap.addView(in);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(wrap).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.confirm(in.getText().toString()); }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { r.cancel(); }
                        }).show();
                return true;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.loadUrl(base() + "/?t=" + Uri.encode(prefs.getString("pin", DEF_PIN).trim()));

        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setTextSize(20);
        gear.setGravity(Gravity.CENTER);
        gear.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.parseColor("#99000000"));
        gear.setBackground(g);
        gear.setContentDescription("Settings");
        gear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettings(null); }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.START);
        lp.setMargins(dp(14), 0, 0, dp(18));
        root.addView(gear, lp);
    }

    private EditText field(LinearLayout box, String label, String value, int inputType) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(Color.parseColor("#7D6F60"));
        l.setTextSize(13);
        l.setPadding(0, dp(14), 0, dp(4));
        box.addView(l);
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(17);
        box.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void showSettings(String error) {
        if (form != null) root.removeView(form);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#FFF8EC"));
        sv.setClickable(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(36), dp(22), dp(28));
        sv.addView(box);

        TextView title = new TextView(this);
        title.setText("Parent Remote settings");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#2A2118"));
        box.addView(title);

        if (error != null) {
            TextView er = new TextView(this);
            er.setText(error);
            er.setTextColor(Color.parseColor("#D64545"));
            er.setTextSize(14);
            er.setPadding(0, dp(10), 0, 0);
            box.addView(er);
        }

        scanStatus = new TextView(this);
        scanStatus.setTextColor(Color.parseColor("#2E7D4F"));
        scanStatus.setTextSize(14);
        scanStatus.setPadding(0, dp(10), 0, 0);
        box.addView(scanStatus);

        Button find = new Button(this);
        find.setText("🔍 Find server on Wi-Fi");
        find.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { findServer(); }
        });
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp.topMargin = dp(12);
        box.addView(find, flp);

        final EditText ip = ipField = field(box, "Mac's IP address (where the dashboard runs)", prefs.getString("ip", DEF_IP),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        final EditText port = field(box, "Port", prefs.getString("port", DEF_PORT), InputType.TYPE_CLASS_NUMBER);
        final EditText pin = field(box, "PIN", prefs.getString("pin", DEF_PIN),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

        TextView hint = new TextView(this);
        hint.setText("The PIN is the part after ?t= in the dashboard link. The Mac's IP is shown when the server starts (On your phone: http://IP:8765/…).");
        hint.setTextColor(Color.parseColor("#7D6F60"));
        hint.setTextSize(12);
        hint.setPadding(0, dp(12), 0, 0);
        box.addView(hint);

        Button save = new Button(this);
        save.setText("Save & connect");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String p = port.getText().toString().trim();
                if (!p.matches("\\d{2,5}")) p = DEF_PORT;
                prefs.edit().putString("ip", ip.getText().toString().trim())
                        .putString("port", p)
                        .putString("pin", pin.getText().toString().trim()).apply();
                showWeb();
            }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(20);
        box.addView(save, blp);

        Button reset = new Button(this);
        reset.setText("Reset to defaults");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ip.setText(DEF_IP); port.setText(DEF_PORT); pin.setText(DEF_PIN);
            }
        });
        box.addView(reset, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (error == null) {
            Button cancel = new Button(this);
            cancel.setText("Back to the remote");
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { root.removeView(form); form = null; }
            });
            box.addView(cancel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        form = sv;
        root.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private TextView scanStatus;
    private EditText ipField;
    private final AtomicBoolean scanning = new AtomicBoolean(false);

    private void status(final String msg) {
        ui.post(new Runnable() { public void run() { if (scanStatus != null) scanStatus.setText(msg); } });
    }

    /** Phone's own IPv4 addresses + prefix lengths on Wi-Fi / LAN interfaces. */
    private List<int[]> localNets() {
        List<int[]> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName();
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun") || n.startsWith("dummy")) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        byte[] b = a.getAddress();
                        int v = ((b[0] & 255) << 24) | ((b[1] & 255) << 16) | ((b[2] & 255) << 8) | (b[3] & 255);
                        out.add(new int[]{v, Math.max(ia.getNetworkPrefixLength(), 22)});
                    }
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static String ipStr(int v) {
        return ((v >>> 24) & 255) + "." + ((v >>> 16) & 255) + "." + ((v >>> 8) & 255) + "." + (v & 255);
    }

    /** True if http://host:port/ serves the TV Remote dashboard page. */
    private static boolean probe(String host, String port, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + host + ":" + port + "/").openConnection();
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs * 3);
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            byte[] buf = new byte[4096];
            int n, total = 0;
            StringBuilder sb = new StringBuilder();
            while (total < 4096 && (n = in.read(buf, 0, 4096 - total)) > 0) { sb.append(new String(buf, 0, n, "UTF-8")); total += n; }
            return sb.indexOf("<title>TV Remote</title>") >= 0;
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void findServer() {
        if (!scanning.compareAndSet(false, true)) return;
        final String port = prefs.getString("port", DEF_PORT).trim();
        final String last = prefs.getString("ip", DEF_IP).trim();
        status("Searching the Wi-Fi for the dashboard…");
        new Thread(new Runnable() { public void run() {
            final List<int[]> nets = localNets();
            if (nets.isEmpty()) { scanning.set(false); status("Phone isn't on Wi-Fi. Connect to home Wi-Fi and try again."); return; }
            // Last-known and default IPs first (fast path).
            for (String h : new String[]{last, DEF_IP}) {
                if (probe(h, port, 800)) { found(h); return; }
            }
            List<String> hosts = new ArrayList<>();
            for (int[] net : nets) {
                int mask = net[1] >= 32 ? -1 : ~((1 << (32 - net[1])) - 1);
                int start = (net[0] & mask) + 1, end = (net[0] | ~mask) - 1;
                for (int v = start; v <= end; v++) if (v != net[0]) hosts.add(ipStr(v));
            }
            final int total = hosts.size();
            final AtomicInteger done = new AtomicInteger();
            final AtomicBoolean hit = new AtomicBoolean(false);
            ExecutorService pool = Executors.newFixedThreadPool(48);
            for (final String h : hosts) {
                pool.execute(new Runnable() { public void run() {
                    if (hit.get()) return;
                    if (probe(h, port, 400) && hit.compareAndSet(false, true)) found(h);
                    int d = done.incrementAndGet();
                    if (d % 32 == 0 && !hit.get()) status("Searching… " + d + " / " + total);
                }});
            }
            pool.shutdown();
            try { pool.awaitTermination(90, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            if (!hit.get()) {
                scanning.set(false);
                status("Dashboard not found on port " + port + ". Is the Mac on, awake, and on the same Wi-Fi?");
            }
        }}).start();
    }

    private void found(final String host) {
        scanning.set(false);
        ui.post(new Runnable() { public void run() {
            prefs.edit().putString("ip", host).apply();
            if (ipField != null) ipField.setText(host);
            if (scanStatus != null) scanStatus.setText("Found the dashboard at " + host + " ✓ Connecting…");
            ui.postDelayed(new Runnable() { public void run() { autoScanned = false; showWeb(); } }, 700);
        }});
    }

    @Override
    public void onBackPressed() {
        if (form != null && web != null) { root.removeView(form); form = null; return; }
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }
}
