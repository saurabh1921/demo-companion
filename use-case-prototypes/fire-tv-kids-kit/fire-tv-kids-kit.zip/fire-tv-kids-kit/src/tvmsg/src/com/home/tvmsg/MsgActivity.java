package com.home.tvmsg;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * Shows a big message card over whatever is playing.
 *
 * am start -n com.home.tvmsg/.MsgActivity --es text "Time to brush teeth!" \
 *     [--es title "A message for you"] [--ei secs 30] [--ez speak true]
 */
public class MsgActivity extends Activity {
    private final Handler handler = new Handler();
    private TextToSpeech tts;
    private final Runnable closer = new Runnable() {
        @Override public void run() { finish(); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        show(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        show(intent);
    }

    private void show(Intent intent) {
        String text = intent.getStringExtra("text");
        if (text == null || text.trim().isEmpty()) text = "Hello!";
        String title = intent.getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "💌 A message for you";
        int secs = intent.getIntExtra("secs", 30);
        boolean speak = intent.getBooleanExtra("speak", true);

        DisplayMetrics dm = getResources().getDisplayMetrics();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xB3000000);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = (int) (48 * dm.density);
        card.setPadding(pad, pad, pad, (int) (pad * 0.7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFF4D6);
        bg.setCornerRadius(36 * dm.density);
        bg.setStroke((int) (6 * dm.density), 0xFFFFB648);
        card.setBackground(bg);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(30);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(0xFF8A4B00);
        titleView.setGravity(Gravity.CENTER);
        card.addView(titleView);

        TextView body = new TextView(this);
        body.setText(text);
        body.setTextSize(text.length() > 80 ? 34 : 46);
        body.setTextColor(0xFF1F1F1F);
        body.setGravity(Gravity.CENTER);
        body.setLineSpacing(0, 1.1f);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bodyLp.topMargin = (int) (24 * dm.density);
        bodyLp.bottomMargin = (int) (28 * dm.density);
        card.addView(body, bodyLp);

        TextView hint = new TextView(this);
        hint.setText("Press OK to close");
        hint.setTextSize(18);
        hint.setTextColor(0xFF8C7A5B);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintLp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(hint, hintLp);

        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                (int) (dm.widthPixels * 0.7), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(card, cardLp);
        setContentView(root);

        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 400);
        } catch (RuntimeException ignored) { }

        if (speak) speakLater(text);

        handler.removeCallbacks(closer);
        if (secs > 0) handler.postDelayed(closer, secs * 1000L);
    }

    private void speakLater(final String text) {
        if (tts != null) tts.shutdown();
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS || tts == null) return;
                Locale loc = Locale.UK;   // Pico voice (built in) — Ivona has no voice installed on this TV
                if (tts.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) loc = Locale.US;
                tts.setLanguage(loc);
                tts.setSpeechRate(0.9f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "msg");
            }
        }, "com.svox.pico");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_BUTTON_A) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(closer);
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        super.onDestroy();
    }
}
