#!/bin/bash
# Builds tvmsg.apk with plain SDK tools (no Gradle).
set -euo pipefail
cd "$(dirname "$0")"
SDK="$HOME/Library/Android/sdk"
BT="$SDK/build-tools/34.0.0"
PLAT="$SDK/platforms/android-34/android.jar"
export PATH="/opt/homebrew/opt/openjdk@17/bin:$PATH"
rm -rf build && mkdir -p build/classes
"$BT/aapt2" link -o build/base.apk -I "$PLAT" --manifest AndroidManifest.xml \
  --min-sdk-version 22 --target-sdk-version 28
javac -nowarn -source 8 -target 8 -classpath "$PLAT" -d build/classes $(find src -name '*.java') 2>&1 | grep -v "bootstrap classpath\|^warning\|^1 warning" || true
"$BT/d8" --min-api 22 --lib "$PLAT" --output build $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build && zip -q unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
[ -f debug.keystore ] || keytool -genkeypair -keystore debug.keystore -storepass android \
  -keypass android -alias tvmsg -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=TV Message" >/dev/null 2>&1
"$BT/apksigner" sign --ks debug.keystore --ks-pass pass:android --out tvmsg.apk build/aligned.apk
echo "Built $(pwd)/tvmsg.apk"
